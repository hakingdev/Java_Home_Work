public class MonthInfo {
    private final int averageTemperature;
    private final String season;

    public MonthInfo(int averageTemperature, String season) {
        this.averageTemperature = averageTemperature;
        this.season = season;
    }

    public int getAverageTemperature() {
        return averageTemperature;
    }

    public String getSeason() {
        return season;
    }

    @Override
    public String toString() {
        return "MonthInfo{" +
                "averageTemperature=" + averageTemperature +
                ", season='" + season + '\'' +
                '}';
    }
}
