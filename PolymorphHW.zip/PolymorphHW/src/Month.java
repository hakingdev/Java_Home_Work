public enum Month {
    JANUARY(0, "Winter"),
    FEBRUARY(3, "Winter"),
    MARCH(8, "Spring"),
    APRIL(15, "Spring"),
    MAY(20, "Spring"),
    JUNE(25, "Summer"),
    JULY(28, "Summer"),
    AUGUST(27, "Summer"),
    SEPTEMBER(23, "Autumn"),
    OCTOBER(16, "Autumn"),
    NOVEMBER(9, "Autumn"),
    DECEMBER(3, "Winter");
    ;
    private final MonthInfo monthInfo;

    Month(int averageTemperature, String season) {
        this.monthInfo = new MonthInfo(averageTemperature, season);
    }

    @Override
    public String toString() {
        return "Month{" +
                "monthInfo=" + monthInfo +
                '}';
    }
    public MonthInfo getMonthInfo() {
        return monthInfo;
    }
}
