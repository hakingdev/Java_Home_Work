public class Triangle extends  Shape implements IPrintable{
    private final double side1;
    private final double side2;
    private final double side3;

    public Triangle(double side1, double side2, double side3) {
        this.name = "Треугольник";
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
    }

    @Override
    public double calculateArea() {
        double s = (side1 + side2 + side3) / 2.0;
        return Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
    }

    @Override
    public double calculatePerimeter() {
        return side1 + side2 + side3;
    }

    @Override
    public void displayCharacteristics() {
        System.out.println("Название: " + name);
        System.out.println("Площадь: " + calculateArea());
        System.out.println("Периметр: " + calculatePerimeter());
        System.out.println("Сторона 1 и противолежащий угол: " + side1 + ", " + calculateOppositeAngle(side1, side2, side3));
        System.out.println("Сторона 2 и противолежащий угол: " + side2 + ", " + calculateOppositeAngle(side2, side1, side3));
        System.out.println("Сторона 3 и противолежащий угол: " + side3 + ", " + calculateOppositeAngle(side3, side1, side2));
    }

    public double calculateOppositeAngle(double a, double b, double c) {
        return Math.toDegrees(Math.acos((b * b + c * c - a * a) / (2 * b * c)));
    }

    @Override
    public void print() {
        System.out.println("Треугольник: ⊿");
    }
}
