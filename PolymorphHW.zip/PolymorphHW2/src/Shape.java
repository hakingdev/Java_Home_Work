public abstract class Shape {
    protected String name;

    public abstract double calculateArea();
    public abstract double calculatePerimeter();
    public abstract void displayCharacteristics();
}
