import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Введите геометрическую фигуру и ее параметры: (К примеру Круг 5):");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        ShapeParser parser = new ShapeParser();
        Shape shape = parser.parseShape(input);
        if (shape != null) {
            shape.displayCharacteristics();
        } else {
            System.out.println("Некорректный ввод.");
        }
        IPrintable[] shapes = new IPrintable[3];
        shapes[0] = new Circle(5);
        shapes[1] = new Rectangle(3, 4);
        shapes[2] = new Triangle(3, 4, 5);
        for (IPrintable s : shapes) {
            s.print();
        }
    }
}