public class ShapeParser {
    public Shape parseShape(String input) {
        String[] parts = input.split(" ");
        if (parts.length < 2) {
            return null;
        }
        String shapeType = parts[0].toLowerCase();
        switch (shapeType) {
            case "круг":
                try {
                    double radius = Double.parseDouble(parts[1]);
                    return new Circle(radius);
                } catch (NumberFormatException e) {
                    return null;
                }
            case "прямоугольник":
                if (parts.length < 3) {
                    return null;
                }
                try {
                    double length = Double.parseDouble(parts[1]);
                    double width = Double.parseDouble(parts[2]);
                    return new Rectangle(length, width);
                } catch (NumberFormatException e) {
                    return null;
                }
            case "треугольник":
                if (parts.length < 4) {
                    return null;
                }
                try {
                    double side1 = Double.parseDouble(parts[1]);
                    double side2 = Double.parseDouble(parts[2]);
                    double side3 = Double.parseDouble(parts[3]);
                    return new Triangle(side1, side2, side3);
                } catch (NumberFormatException e) {
                    return null;
                }
            default:
                return null;
        }
    }
}
