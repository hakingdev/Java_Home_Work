public interface IPrintable {
    void print();
}
