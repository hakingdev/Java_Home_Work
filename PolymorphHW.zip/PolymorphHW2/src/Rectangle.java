public class Rectangle extends Shape implements IPrintable{
    private final double length;
    private final double width;

    public Rectangle(double length, double width) {
        this.name = "Прямоугольник";
        this.length = length;
        this.width = width;
    }

    @Override
    public double calculateArea() {
        return length * width;
    }

    @Override
    public double calculatePerimeter() {
        return 2 * (length + width);
    }

    @Override
    public void displayCharacteristics() {
        System.out.println("Название: " + name);
        System.out.println("Площадь: " + calculateArea());
        System.out.println("Периметр: " + calculatePerimeter());
        System.out.println("Длина: " + length);
        System.out.println("Ширина: " + width);
        System.out.println("Длина диагонали: " + Math.sqrt(length * length + width * width));
    }

    @Override
    public void print() {
        System.out.println("Прямоугольник: ⧠");
    }
}
