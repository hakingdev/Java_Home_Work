public class Circle extends Shape implements IPrintable{
    private final double radius;

    public Circle(double radius) {
        this.radius = radius;
        this.name = "Круг";
    }

    @Override
    public double calculateArea() {
        return Math.PI * radius * radius;
    }

    @Override
    public double calculatePerimeter() {
        return Math.PI * radius * 2;
    }

    @Override
    public void displayCharacteristics() {
        System.out.println("Название: " + name);
        System.out.println("Площадь: " + calculateArea());
        System.out.println("Периметр: " + calculatePerimeter());
        System.out.println("Радиус: " + radius);
        System.out.println("Диаметр: " + (2 * radius));
    }

    @Override
    public void print() {
        System.out.println("Круг: ◍");
    }
}
