package bicycle;

public enum BicycleType {
    KIDSBICYCLE,
    MOUNTAINBIKE,
    RACINGBICYCLE

}
