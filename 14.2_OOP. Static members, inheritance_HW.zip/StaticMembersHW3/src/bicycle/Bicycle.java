package bicycle;

public class Bicycle {
    private int speed;
    private int numberOfTransmissions;
    private String brandName;
    private int numberOfWheels;
    private BicycleType bicycleType;

    public Bicycle(int speed, int numberOfTransmissions, String brandName, int numberOfWheels, BicycleType bicycleType) {
        this.speed = speed;
        this.numberOfTransmissions = numberOfTransmissions;
        this.brandName = brandName;
        this.numberOfWheels = numberOfWheels;
        this.bicycleType = bicycleType;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public void setNumberOfTransmissions(int numberOfTransmissions) {
        this.numberOfTransmissions = numberOfTransmissions;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public void setNumberOfWheels(int numberOfWheels) {
        this.numberOfWheels = numberOfWheels;
    }

    public void setBicycleType(BicycleType bicycleType) {
        this.bicycleType = bicycleType;
    }

    public int getSpeed() {
        return speed;
    }

    public int getNumberOfTransmissions() {
        return numberOfTransmissions;
    }

    public String getBrandName() {
        return brandName;
    }

    public int getNumberOfWheels() {
        return numberOfWheels;
    }

    public BicycleType getBicycleType() {
        return bicycleType;
    }

    @Override
    public String toString() {
        return "Bicycle{" +
                "speed=" + speed +
                ", numberOfTransmissions=" + numberOfTransmissions +
                ", brandName='" + brandName + '\'' +
                ", numberOfWheels=" + numberOfWheels +
                ", bicycleType=" + bicycleType +
                '}';
    }
}
