import bicycle.Bicycle;
import bicycle.BicycleType;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Bicycle kidBike = new Bicycle(5, 5, "Bacchetta", 3, BicycleType.KIDSBICYCLE);
        Bicycle mountainBike = new Bicycle(35, 12, "Trek", 3, BicycleType.MOUNTAINBIKE);
        Bicycle racingBicycle = new Bicycle(50, 18, "Specialized", 3, BicycleType.RACINGBICYCLE);
        System.out.println(kidBike);
        System.out.println(mountainBike);
        System.out.println(racingBicycle);
        Bicycle[] bicycles = {kidBike, mountainBike, racingBicycle};
        System.out.printf(Arrays.toString(bicycles));
    }
}