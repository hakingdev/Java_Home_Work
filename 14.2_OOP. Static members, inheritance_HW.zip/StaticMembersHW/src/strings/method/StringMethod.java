package strings.method;

import java.util.Random;

public class StringMethod {
    private StringMethod() {}

    public static String generateWord(int length) {
        StringBuilder string = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            char letter = (char) (random.nextInt(26) + 'a');
            string.append(letter);
        }
        return string.toString();
    }

    public static String generateNumeric(int length) {
        StringBuilder string = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            char letter = (char) (random.nextInt(10) + '0');
            string.append(letter);
        }
        return string.toString();
    }

    public static String[] splitByFirst(String input) {
        String[] result = new String[2];
        int index = 0;
        while (index < input.length() && (Character.isLetter(input.charAt(index)) || Character.isDigit(input.charAt(index)))) {
            index++;
        }
        result[0] = input.substring(0, index).trim();
        result[1] = input.substring(index).trim();
        return result;
    }

    public static boolean isNumeric(String input) {
        for (int i = 0; i < input.length(); i++) {
            if (!Character.isDigit(input.charAt(i))) {
                return false;
            }
        }
        return true;
    }
}
