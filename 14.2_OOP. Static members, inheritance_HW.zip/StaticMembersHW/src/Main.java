import strings.method.StringMethod;

public class Main {
    public static void main(String[] args) {
        String word = StringMethod.generateWord(5);
        String number = StringMethod.generateNumeric(3);
        System.out.println(word + number);
        String numericString = "98369";
        System.out.println("This is true numeric ? " + StringMethod.isNumeric(numericString));
        String input = "Hello! World ? I'm happy!";
        String[] split = StringMethod.splitByFirst(input);
        for (String s : split) {
            System.out.println(s);
        }
    }
}