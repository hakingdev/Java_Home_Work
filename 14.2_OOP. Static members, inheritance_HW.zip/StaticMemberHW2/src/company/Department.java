package company;

import java.util.ArrayList;
import java.util.List;
// Композиция (Один ко многим) Каждый депортамент принадлежит одной организации
public class Department {
    private final String name;
    private final List<Employee> employees;

    public Department(String name) {
        this.name = name;
        this.employees = new ArrayList<>();
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }



    public String getName() {
        return name;
    }

    public List<Employee> getEmployees() {
        return employees;
    }
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("Department{" +
                "name = '" + name + '\'' +
                ", employees = ");
        for (Employee employee : employees) {
            builder.append("{ name = ").append(employee.getName()).append(", gender = ").append(employee.getGender()).append(", salary = ").append(employee.getSalary()).append("}, ");
        }
        builder.append('}');
        return builder.toString();
    }
}
