package company;
//Ассоциация (Сотрудник -> Директор департамента) многий ко многим
//Композиция (Сотрудник -> Департамент) один ко многим
public class Employee {
    private final String gender;
    private final int age;
    private final String name;
    private final int salary;
    private Department department;


    public Employee(String gender, int age, String name, int salary, Department department) {
        this.gender = gender;
        this.age = age;
        this.name = name;
        this.salary = salary;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public String getGender() {
        return gender;
    }

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

    public int getSalary() {
        return salary;
    }

    public Department getDepartment() {
        return department;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "gender = '" + gender + '\'' +
                ", age = " + age +
                ", name = '" + name + '\'' +
                ", salary = " + salary +
                ", department = " + (department != null ? department.getName() : "null") +
                '}';
    }
}
