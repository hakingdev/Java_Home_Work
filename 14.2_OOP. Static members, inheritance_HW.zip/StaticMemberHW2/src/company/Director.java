package company;

import java.util.List;
// Композиция (Один ко многим) Каждый директор принадлежит одной организации
public class Director extends Employee {
    public Director(String gender, int age, String name, int salary, Department department) {
        super(gender, age, name, salary, department);
    }


}
