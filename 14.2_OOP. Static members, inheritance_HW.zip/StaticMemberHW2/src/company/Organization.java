package company;

import java.util.List;

public class Organization {
    private final String name;
    private final List<Department> departments;
    private Director director;

    public Organization(String name, List<Department> departments, Director director) {
        this.name = name;
        this.departments = departments;
        this.director = director;
    }

    public void addDirector(Director director) {
        this.director = director;
    }

    public void setDirector(Director director) {
        this.director = director;
    }

    public String getName() {
        return name;
    }

    public List<Department> getDepartments() {
        return departments;
    }

    public Director getDirector() {
        return director;
    }

    @Override
    public String toString() {
        return "Organization{" +
                "name='" + name + '\'' +
                ", departments=" + departments +
                ", director=" + director +
                '}';
    }
}
