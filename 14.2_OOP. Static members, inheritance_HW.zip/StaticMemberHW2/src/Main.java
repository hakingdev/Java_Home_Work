import company.Department;
import company.Director;
import company.Employee;

import java.sql.Driver;

public class Main {
    public static void main(String[] args) {
        // Создаем департамент
        Department department = new Department("IT Department");

        Director director = new Director("Man", 31, "John", 5000, department);

        Employee employee1 = new Employee("Woman",24, "Alice", 3000, department);
        Employee employee2 = new Employee("Man",28, "Alex", 4500, department);
        employee1.setDepartment(department);
        employee2.setDepartment(department);
        department.addEmployee(employee1);
        department.addEmployee(employee2);
        System.out.println(employee1 + " work in " + employee1.getDepartment().getName());
        System.out.println(employee2 + " work in " + employee1.getDepartment().getName());

    }
}