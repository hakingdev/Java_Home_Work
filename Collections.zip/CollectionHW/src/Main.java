import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите строку, если хотите завершить введите 'quit'");
        while (true) {
            String line = scanner.nextLine();
            if(line.equals("quit")) break;
            list.add(line);
        }
        System.out.println("Ваши введеные строки");
        for (String line : list) {
            System.out.println(line);
        }
        String longest = findLongestString(list);
        String shortest = findShortString(list);
        System.out.println("Самая длинная строка " + longest);
        System.out.println("Самая короткая строка " + shortest);
    }

    public static String findShortString(ArrayList<String> strings) {
        String shortes = strings.getFirst();
        for (String string : strings) {
            if(string.length() < shortes.length()) shortes = string;
        }
        return shortes;
    }

    public static String findLongestString(ArrayList<String> strings) {
        String longest = "";
        for (String string : strings) {
            if (string.length() > longest.length()) longest = string;
        }
        return longest;
    }
}