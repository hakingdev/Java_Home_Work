package group;

import java.util.ArrayList;

public class Group {
    private ArrayList<String> students;

    public Group() {
        this.students = new ArrayList<>();
    }

    public void addStudent(String surname) {
        this.students.add(surname);
    }

    public ArrayList<String> findStudentsBySurname(String startsWith) {
        ArrayList<String> foundStudents = new ArrayList<>();
        for (String student : students) {
            if(student.startsWith(startsWith)) foundStudents.add(student);
        }
        return foundStudents;
    }
}
