import group.Group;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Group group = new Group();
        group.addStudent("Ivanov");
        group.addStudent("Mahnov");
        group.addStudent("Frolova");
        group.addStudent("Petryk");

        ArrayList<String> foundStudents = group.findStudentsBySurname("P");
        for (String foundStudent : foundStudents) {
            System.out.println(foundStudent);
        }
    }
}