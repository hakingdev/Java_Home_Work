import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Main {
    public static void main(String[] args) {
        ArrayList<Integer> numbers = generateRandomNumbers(10);
        System.out.println("Список до удаления");
        System.out.println(numbers);

        removeNegativeNumbers(numbers);
        System.out.println("Список после удаления");
        System.out.println(numbers);
    }

    public static ArrayList<Integer> generateRandomNumbers(int count) {
        ArrayList<Integer> number = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < count; i++) {
            int randomNumber = ThreadLocalRandom.current().nextInt(-100, 101);
            number.add(randomNumber);
        }
        return number;
    }

    public static void removeNegativeNumbers(ArrayList<Integer> numbers) {
        numbers.removeIf(n -> n < 0);
    }
}